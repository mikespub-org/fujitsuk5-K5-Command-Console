# K5-Sample-Application

This is a sample application that consumes the Cloud Service K5 APIs.

Download and extract the Zip to run the EXE.
